//
//  SeatCollectionViewCell.swift
//  iosDevelopment_Assignment3
//
//  Created by Yinpeng on 17/05/2022.
//

import UIKit

class SeatCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var indexLabel: UILabel!
    
    @IBOutlet weak var markImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
